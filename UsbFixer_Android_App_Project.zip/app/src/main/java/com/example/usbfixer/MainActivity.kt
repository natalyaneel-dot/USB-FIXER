package com.example.usbfixer

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import me.jahnen.libaums.core.UsbMassStorageDevice
import me.jahnen.libaums.core.driver.BlockDeviceDriver
import me.jahnen.libaums.core.driver.BlockDeviceDriverFactory
import me.jahnen.libaums.core.fs.UsbFile
import me.jahnen.libaums.core.fs.UsbFileInputStream
import me.jahnen.libaums.core.usb.UsbCommunicationFactory
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer

class MainActivity : AppCompatActivity() {

    private val ACTION_USB_PERMISSION = "com.example.usbfixer.USB_PERMISSION"
    private lateinit var statusText: TextView
    private lateinit var filesContainer: LinearLayout
    private lateinit var progressBar: ProgressBar
    private var currentStorageDevice: UsbMassStorageDevice? = null
    private var currentDir: UsbFile? = null

    private val usbReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (ACTION_USB_PERMISSION == intent.action) {
                synchronized(this) {
                    val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
                    if (granted) {
                        startFixAndReadProcess()
                    } else {
                        statusText.text = "❌ تم رفض صلاحية الوصول للفلاشة. يرجى الموافقة لفتح الملفات."
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 36)
            setBackgroundColor(Color.parseColor("#F8FAFC"))
        }

        val titleText = TextView(this).apply {
            text = "أداة إصلاح الإقلاع وقراءة الفلاشة بدون فورمات"
            textSize = 19f
            setTextColor(Color.parseColor("#0F172A"))
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }

        val btnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        val scanButton = Button(this).apply {
            text = "🔧 إصلاح الإقلاع وفتح الفلاشة"
            setBackgroundColor(Color.parseColor("#2563EB"))
            setTextColor(Color.WHITE)
            setPadding(32, 20, 32, 20)
        }

        val upButton = Button(this).apply {
            text = "⬆️ رجوع للمجلد السابق"
            setPadding(24, 20, 24, 20)
            setOnClickListener {
                currentDir?.parent?.let { parentDir ->
                    currentDir = parentDir
                    renderDirectory(parentDir)
                }
            }
        }

        btnRow.addView(scanButton)
        btnRow.addView(upButton)

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            isIndeterminate = true
            visibility = android.view.View.GONE
            setPadding(0, 16, 0, 16)
        }

        statusText = TextView(this).apply {
            text = "قم بتوصيل الفلاشة بالهاتف عبر وصلة OTG ثم اضغط على زر الإصلاح."
            textSize = 15f
            setTextColor(Color.parseColor("#334155"))
            setPadding(16, 24, 16, 24)
        }

        val scrollView = ScrollView(this)
        filesContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scrollView.addView(filesContainer)

        rootLayout.addView(titleText)
        rootLayout.addView(btnRow)
        rootLayout.addView(progressBar)
        rootLayout.addView(statusText)
        rootLayout.addView(scrollView)

        setContentView(rootLayout)

        val filter = IntentFilter(ACTION_USB_PERMISSION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(usbReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(usbReceiver, filter)
        }

        scanButton.setOnClickListener {
            checkUsbAndRequestPermission()
        }
    }

    private fun checkUsbAndRequestPermission() {
        val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        val devices = UsbMassStorageDevice.getMassStorageDevices(this)

        if (devices.isEmpty()) {
            statusText.text = "⚠️ لم يتم العثور على أي فلاشة متصلة! تأكد من توصيل وصلة OTG جيداً."
            return
        }

        val device = devices[0]
        if (!usbManager.hasPermission(device.usbDevice)) {
            val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
            val permissionIntent = PendingIntent.getBroadcast(this, 0, Intent(ACTION_USB_PERMISSION), flags)
            usbManager.requestPermission(device.usbDevice, permissionIntent)
        } else {
            startFixAndReadProcess()
        }
    }

    private fun startFixAndReadProcess() {
        progressBar.visibility = android.view.View.VISIBLE
        statusText.text = "⏳ جاري فحص قطاع الإقلاع (Boot Sector) وإزالة علامة التلف (Dirty Bit)..."

        Thread {
            try {
                val devices = UsbMassStorageDevice.getMassStorageDevices(this)
                if (devices.isEmpty()) return@Thread
                val storageDevice = devices[0]
                currentStorageDevice = storageDevice

                val fixLog = repairBootSectorDirtyBit(storageDevice)

                storageDevice.init()
                if (storageDevice.partitions.isEmpty()) {
                    runOnUiThread {
                        progressBar.visibility = android.view.View.GONE
                        statusText.text = "❌ لم يتم العثور على أقسام صالحة، قد يكون نظام الملفات NTFS."
                    }
                    return@Thread
                }

                val partition = storageDevice.partitions[0]
                val rootDir = partition.fileSystem.rootDirectory
                currentDir = rootDir

                runOnUiThread {
                    progressBar.visibility = android.view.View.GONE
                    statusText.text = "✅ $fixLog
اضغط على أي مجلد لفتحه، أو اضغط على أي ملف لنسخه فوراً إلى مجلد التنزيلات (Downloads) في هاتفك:"
                    renderDirectory(rootDir)
                }

            } catch (e: Exception) {
                runOnUiThread {
                    progressBar.visibility = android.view.View.GONE
                    statusText.text = "⚠️ تعذر فتح الفلاشة: ${e.message}"
                }
            }
        }.start()
    }

    private fun renderDirectory(dir: UsbFile) {
        filesContainer.removeAllViews()
        Thread {
            try {
                val files = dir.listFiles()
                runOnUiThread {
                    if (files.isEmpty()) {
                        val emptyView = TextView(this).apply {
                            text = "(هذا المجلد فارغ)"
                            setPadding(16, 16, 16, 16)
                        }
                        filesContainer.addView(emptyView)
                        return@runOnUiThread
                    }

                    for (file in files) {
                        val itemBtn = Button(this).apply {
                            val icon = if (file.isDirectory) "📁 [مجلد]" else "📄 [ملف - اضغط للنسخ]"
                            val sizeInfo = if (!file.isDirectory) " (${file.length / 1024} KB)" else ""
                            text = "$icon ${file.name}$sizeInfo"
                            gravity = Gravity.START or Gravity.CENTER_VERTICAL
                            isAllCaps = false
                            setPadding(24, 20, 24, 20)

                            setOnClickListener {
                                if (file.isDirectory) {
                                    currentDir = file
                                    renderDirectory(file)
                                } else {
                                    copyUsbFileToDownloads(file)
                                }
                            }
                        }
                        filesContainer.addView(itemBtn)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "خطأ في قراءة المجلد: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun copyUsbFileToDownloads(usbFile: UsbFile) {
        progressBar.visibility = android.view.View.VISIBLE
        statusText.text = "⏳ جاري إنقاذ ونسخ الملف (${usbFile.name}) إلى الهاتف..."

        Thread {
            try {
                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                val recoveryFolder = File(downloadsDir, "USB_Recovered_Files")
                if (!recoveryFolder.exists()) recoveryFolder.mkdirs()

                val destFile = File(recoveryFolder, usbFile.name)
                UsbFileInputStream(usbFile).use { input ->
                    FileOutputStream(destFile).use { output ->
                        val buffer = ByteArray(8192)
                        var read: Int
                        while (input.read(buffer).also { read = it } != -1) {
                            output.write(buffer, 0, read)
                        }
                    }
                }

                runOnUiThread {
                    progressBar.visibility = android.view.View.GONE
                    statusText.text = "✅ تم إنقاذ الملف وحفظه بنجاح في:
Downloads/USB_Recovered_Files/${usbFile.name}"
                    Toast.makeText(this, "تم الحفظ في التنزيلات!", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progressBar.visibility = android.view.View.GONE
                    statusText.text = "❌ فشل نسخ الملف: ${e.message}"
                }
            }
        }.start()
    }

    private fun repairBootSectorDirtyBit(device: UsbMassStorageDevice): String {
        return try {
            val usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
            val usbDevice = device.usbDevice
            val interfaceUsb = usbDevice.getInterface(0)
            val inEndpoint = interfaceUsb.getEndpoint(0)
            val outEndpoint = interfaceUsb.getEndpoint(1)

            val usbComm = UsbCommunicationFactory.createUsbCommunication(
                usbManager, usbDevice, interfaceUsb, outEndpoint, inEndpoint
            )
            val blockDriver: BlockDeviceDriver = BlockDeviceDriverFactory.createBlockDevice(usbComm)
            blockDriver.init()

            val buffer = ByteBuffer.allocate(512)
            blockDriver.read(0, buffer)
            val mbr = buffer.array()
            var repairMsg = "تم فحص قطاع الإقلاع بنجاح."

            if (mbr[510] == 0x55.toByte() && mbr[511] == 0xAA.toByte()) {
                val partitionStartLba = (mbr[454].toInt() and 0xFF) or
                        ((mbr[455].toInt() and 0xFF) shl 8) or
                        ((mbr[456].toInt() and 0xFF) shl 16) or
                        ((mbr[457].toInt() and 0xFF) shl 24)

                val vbrBuffer = ByteBuffer.allocate(512)
                val targetSector = if (partitionStartLba > 0) partitionStartLba.toLong() else 0L

                blockDriver.read(targetSector, vbrBuffer)
                val vbr = vbrBuffer.array()

                // إصلاح Dirty Bit في نظام FAT32 (البايت 0x41)
                if (vbr[0x41].toInt() and 0x01 != 0) {
                    vbr[0x41] = (vbr[0x41].toInt() and 0xFE).toByte()
                    vbrBuffer.rewind()
                    blockDriver.write(targetSector, vbrBuffer)
                    repairMsg = "تم اكتشاف وإصلاح خطأ الإقلاع (FAT32 Dirty Bit) بنجاح!"
                }

                // إصلاح Dirty Flag في نظام exFAT (البايت 0x6A)
                val isExFat = String(vbr, 3, 5) == "EXFAT"
                if (isExFat && (vbr[0x6A].toInt() and 0x02 != 0)) {
                    vbr[0x6A] = (vbr[0x6A].toInt() and 0xFD).toByte()
                    vbrBuffer.rewind()
                    blockDriver.write(targetSector, vbrBuffer)
                    repairMsg = "تم اكتشاف وإصلاح خطأ الإقلاع (exFAT Volume Dirty Flag) بنجاح!"
                }
            }
            usbComm.close()
            repairMsg
        } catch (e: Exception) {
            "تم تجاوز فحص القطاع الخام والانتقال للقراءة المباشرة."
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        currentStorageDevice?.close()
        unregisterReceiver(usbReceiver)
    }
}
